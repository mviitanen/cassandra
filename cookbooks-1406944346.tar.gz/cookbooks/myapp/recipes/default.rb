#
# Cookbook Name:: myapp
# Recipe:: default
#
# Copyright (C) 2014 YOUR_NAME
#
# All rights reserved - Do Not Redistribute
#


#echo "deb http://debian.datastax.com/community stable main" | sudo tee -a /etc/apt/sources.list.d/cassandra.sources.list
#execute "add-datastax-repo" do
#    command "echo "deb http://debian.datastax.com/community stable main" | sudo tee -a /etc/apt/sources.list.d/cassandra.sources.list"
#end
apt_repository 'datastax' do
  uri          'http://debian.datastax.com/community'
  components   ['stable', 'main']
  key          'http://debian.datastax.com/debian/repo_key'
  arch         'amd64'
end

# 14  curl -L http://debian.datastax.com/debian/repo_key | sudo apt-key add -
#execute "add-datastax-repo" do
#    command "curl -L http://debian.datastax.com/debian/repo_key | sudo apt-key add"
#end




# 15  sudo apt-get update
include_recipe "apt::default"

# 16  sudo apt-get install dsc20
apt_package "install-dsc20" do
  package_name "dsc20"
  action :install
end
