override["java"]["install_flavor"] = "oracle"
override["java"]["jdk_version"]="7"
override["java"]["oracle"]["accept_oracle_download_terms"] = true
